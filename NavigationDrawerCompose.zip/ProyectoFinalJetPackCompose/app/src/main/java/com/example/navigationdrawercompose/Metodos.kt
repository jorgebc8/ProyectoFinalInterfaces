package com.example.navigationdrawercompose

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException
import java.net.URL

@Composable
fun cargarJson(): UserInfo {

    var users by rememberSaveable { mutableStateOf(UserInfo()) }
    val user = UserInstance.userInterface.userInformation()

    user.enqueue(object : Callback<UserInfo> {
        override fun onResponse(
            call: Call<UserInfo>,
            response: Response<UserInfo>
        ) {
            val userInfo: UserInfo? = response.body()
            if (userInfo != null) {
                users = userInfo
            }
        }

        override fun onFailure(call: Call<UserInfo>, t: Throwable) {
            //Error
        }

    })

    return users
}

fun insertar(nombre: String, equipo: String, dorsal: String) {

    /* MODIFICAR LA INSERCCION A LA BASE DE DATOS*/

    val url =
        "http://iesayala.ddns.net/salas/insertjugadores.php/?nombre=$nombre&equipo=$equipo&dorsal=$dorsal"

    leerUrl(url)

}

fun eliminar(nombre: String) {

    /* MODIFICAR LA INSERCCION A LA BASE DE DATOS*/

    val url = "http://iesayala.ddns.net/salas/eliminarjugadores.php/?nombre=$nombre"

    leerUrl(url)

}

fun leerUrl(urlString: String) {
    GlobalScope.launch(Dispatchers.IO) {
        val response = try {
            URL(urlString)
                .openStream()
                .bufferedReader()
                .use { it.readText() }
        } catch (e: IOException) {
            "Error with ${e.message}."
            Log.d("io", e.message.toString())
        } catch (e: Exception) {
            "Error with ${e.message}."
            Log.d("io", e.message.toString())
        }
    }

    /*return*/
}

@Composable
fun HomeScreen() {
    Image(painter = painterResource(id = R.drawable.fondobaloncesto), contentDescription = "Prueba",modifier = Modifier.fillMaxSize())

    val lista = cargarJson()
    Column(){

        Column(modifier = Modifier) {
            Row(modifier = Modifier.fillMaxWidth()) {

                Text(
                    text = "Nombre",
                    modifier = Modifier.weight(1f),

                    fontSize = 32.sp,
                    color = Color.White
                )


                Text(
                    text = "Equipo",
                    modifier = Modifier.weight(1f),
                    fontSize = 32.sp,
                    color = Color.White
                )


                Text(

                    text = "Dorsal",
                    modifier = Modifier.weight(1f),
                    fontSize = 35.sp,
                    color = Color.White
                )


            }
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(5.dp)) {

                items(lista){
                        usu ->
                    Row() {
                        Text(
                            text = usu.nombre,
                            modifier = Modifier.weight(1f),
                            fontSize = 24.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = usu.equipo,
                            modifier = Modifier.weight(1f),
                            fontSize = 24.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = usu.dorsal,
                            modifier = Modifier
                                .weight(1f)
                                .padding(10.dp),
                            fontSize = 24.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Black
                        )
                    }

                }
            }
        }

    }
    
}

@Composable
fun ProfileScreen() {


    Image(painter = painterResource(id = R.drawable.fondobaloncesto), contentDescription = "Prueba",modifier = Modifier.fillMaxSize())
    Column(
        modifier = Modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        var textFieldValueMarca by rememberSaveable { mutableStateOf("") }
        var textFieldValueModelo by rememberSaveable { mutableStateOf("") }
        var textFieldValuePrecio by rememberSaveable { mutableStateOf("") }
        val context = LocalContext.current


        Column(
            modifier = Modifier
                .fillMaxSize()


        ) {
            TextField(
                value = textFieldValueMarca,
                onValueChange = { nuevo ->
                    textFieldValueMarca = nuevo
                },
                label = {
                    Text(text = "Introducir Nombre", style = TextStyle(color = Color.White, fontSize = 20.sp))
                },
                modifier = Modifier
                    .align(alignment = Alignment.CenterHorizontally)
                    .padding(10.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                textStyle = TextStyle(textAlign = TextAlign.Right, color = Color.White, fontSize = 24.sp)
            )
            TextField(
                value = textFieldValueModelo,
                onValueChange = { nuevo ->
                    textFieldValueModelo = nuevo
                },
                label = {
                    Text(text = "Introducir Equipo", style = TextStyle(color = Color.White, fontSize = 20.sp))
                },
                modifier = Modifier
                    .align(alignment = Alignment.CenterHorizontally)
                    .padding(10.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                textStyle = TextStyle(textAlign = TextAlign.Right, color = Color.White, fontSize = 24.sp)
            )
            TextField(
                value = textFieldValuePrecio,
                onValueChange = { nuevo ->
                    textFieldValuePrecio = nuevo
                },
                label = {
                    Text(text = "Introducir Dorsal", style = TextStyle(color = Color.White, fontSize = 20.sp))
                },
                modifier = Modifier
                    .align(alignment = Alignment.CenterHorizontally)
                    .padding(10.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                textStyle = TextStyle(textAlign = TextAlign.Right, color = Color.White, fontSize = 24.sp)
            )

            Spacer(Modifier.height(20.dp))


            TextButton(
                modifier = Modifier
                    .align(alignment = Alignment.CenterHorizontally)
                    .size(width = 150.dp, height = 80.dp),


                onClick = {

                    insertar(textFieldValueMarca, textFieldValueModelo, textFieldValuePrecio)
                    textFieldValueMarca = ""
                    textFieldValueModelo = ""
                    textFieldValuePrecio = ""
                    MaterialAlertDialogBuilder(context, R.style.ThemeOverlay_AppCompat)
                        .setMessage("Jugador añadido")
                        .show()
                }
            ) {
                Text(
                    style = TextStyle(color = Color.White, fontSize = 30.sp),
                    text = "Añadir Jugador"
                )
            }


        }

    }
}

@Composable
fun SettingsScreen() {
    Image(painter = painterResource(id = R.drawable.fondobaloncesto), contentDescription = "Prueba",modifier = Modifier.fillMaxSize())
    Column(
        modifier = Modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally

    )

    {
        var textFieldValueMarca by rememberSaveable { mutableStateOf("") }
        val context = LocalContext.current
        TextField(
            value = textFieldValueMarca,
            onValueChange = { nuevo ->
                textFieldValueMarca = nuevo
            },
            label = {
                Text(text = "Introducir Nombre", style = TextStyle(color = Color.White, fontSize = 20.sp))
            },
            modifier = Modifier
                .align(alignment = Alignment.CenterHorizontally)
                .padding(10.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            textStyle = TextStyle(textAlign = TextAlign.Right, color = Color.White, fontSize = 24.sp)
        )
        Spacer(Modifier.height(20.dp))


        TextButton(
            modifier = Modifier
                .align(alignment = Alignment.CenterHorizontally)
                .size(width = 150.dp, height = 80.dp),

            onClick = {
                eliminar(textFieldValueMarca)
                textFieldValueMarca = ""
                MaterialAlertDialogBuilder(context, R.style.ThemeOverlay_AppCompat)
                    .setMessage("Jugador eliminado")
                    .show()
            }
        ) {
            Text(
                style = TextStyle(color = Color.White, fontSize = 30.sp),
                text = "Eliminar"
            )
        }

    }
}

