package com.example.navigationdrawercompose

class UserInfo : ArrayList<JsonUser>()