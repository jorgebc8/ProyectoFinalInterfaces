package com.example.navigationdrawercompose

data class JsonUser(
    val nombre: String,
    val equipo: String,
    val dorsal: String,
)