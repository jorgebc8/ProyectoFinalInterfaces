package com.example.navigationdrawercompose

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
//hasta mi usiario
const val base_user = "http://iesayala.ddns.net/jorge/"

interface UserInterface {
    @GET("jsonjugadores.php")
    fun userInformation(): Call<UserInfo>
}

object UserInstance {
    val userInterface: UserInterface

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl(base_user)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        userInterface = retrofit.create(UserInterface::class.java)
    }


}