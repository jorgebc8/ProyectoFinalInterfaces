package com.example.navigationdrawercompose

sealed class NavegacionItem(var route: String, var icon: Int, var title: String)
{
    object Home : NavegacionItem("home", R.drawable.ic_home, "Jugadores")
    object Profile : NavegacionItem("profile", R.drawable.ic_profile, "Añadir Jugador")
    object Settings : NavegacionItem("settings", R.drawable.baloncesto, "Eliminar Jugador")
}
